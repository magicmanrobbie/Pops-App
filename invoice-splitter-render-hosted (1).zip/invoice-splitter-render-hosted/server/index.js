
import express from "express";
import cors from "cors";
import multer from "multer";
import pdfParse from "pdf-parse";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

app.use(cors());
app.use(express.json({ limit: "10mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/extract", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded." });
    }

    const filename = (req.file.originalname || "").toLowerCase();
    const mimetype = req.file.mimetype || "";
    let text = "";

    if (filename.endsWith(".pdf") || mimetype.includes("pdf")) {
      const parsed = await pdfParse(req.file.buffer);
      text = parsed.text || "";
    } else {
      text = req.file.buffer.toString("utf8");
    }

    return res.json({
      filename: req.file.originalname,
      characters: text.length,
      text,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error: "Could not extract text from that document. It may be a scanned/image PDF. Try a text-based PDF, or add OCR later.",
    });
  }
});

const clientDist = path.join(__dirname, "..", "client", "dist");

if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));

  app.get("*", (_req, res) => {
    res.sendFile(path.join(clientDist, "index.html"));
  });
} else {
  app.get("/", (_req, res) => {
    res.send("Invoice Splitter API is running. Build the client to serve the web app.");
  });
}

const port = process.env.PORT || 3001;
app.listen(port, () => {
  console.log(`Invoice Splitter running on port ${port}`);
});
