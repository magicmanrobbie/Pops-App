import React from "react";
import { createRoot } from "react-dom/client";
import InvoiceSplitterApp from "./App.jsx";
import "./styles.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <InvoiceSplitterApp />
  </React.StrictMode>
);
