
import React, { useMemo, useState } from "react";

const currency = new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" });
const nl = String.fromCharCode(10);
const tab = String.fromCharCode(9);

const sampleText = [
  "MELIF Limited",
  "Invoice",
  "5313 - £36.46       5309 - £36.46",
  "5314 - £36.46       5304 - £36.46",
  "Emergency Lighting annual drain down",
  "Invoice number: 0188",
  "DATE 20/04/2026",
  "Date BLOCK Amount Work Order",
  "20/04/2026 Janeford Court 6 £36.458 22451",
  "20/04/2026 Janeford Court 4,7-10 36.458 22451",
  "20/04/2026 Frinton Court 6 36.458 22451",
  "20/04/2026 Frinton Court 4,7-10 36.458 22451",
  "20/04/2026 Parklands Court 6 36.458 22451",
  "20/04/2026 Parklands Court 4,7-10 36.458 22451",
  "20/04/2026 Dartford Court 6-7,16-18 36.458 22451",
  "20/04/2026 Dartford Court 19&20 36.458 22451",
  "20/04/2026 Dartford Court 4,14-15 36.458 22451",
  "20/04/2026 Dartford Court 1,11-13 36.458 22451",
  "20/04/2026 Ashford Court 4-8 36.458 22451",
  "20/04/2026 Ashford Court 12-17 36.458 22451",
  "20/04/2026 Ashford Court 25-29 36.458 22451",
  "20/04/2026 Ashford Court 9-24 36.458 22451",
  "20/04/2026 Greenbank Court 7-15 36.458 22451",
  "20/04/2026 Greenbank Court 1-6 36.458 22451",
  "20/04/2026 Darwin Court 4-8 36.458 22451",
  "20/04/2026 Darwin Court 25-29 36.458 22451",
  "20/04/2026 Darwin Court 19-24 36.458 22451",
  "20/04/2026 Darwin Court 9-18 36.458 22451",
  "20/04/2026 Emerson Court 36.458 22451",
  "--- page break ---",
  "20/04/2026 Chaucer Court 36.458 22451",
  "20/04/2026 Mayford Court 36.458 22451",
  "20/04/2026 Kipling Court 36.458 22451",
  "TOTAL £875"
].join(nl);

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function cleanToken(value) {
  return String(value || "").replaceAll("£", "").replaceAll(",", "").replaceAll(":", "").trim();
}

function toNumber(value) {
  const number = Number(cleanToken(value));
  return Number.isFinite(number) ? number : 0;
}

function money(value) {
  return currency.format(toNumber(value));
}

function splitMany(value, separators) {
  let parts = [String(value || "")];
  separators.forEach((separator) => {
    parts = parts.flatMap((part) => part.split(separator));
  });
  return parts.map((part) => part.trim()).filter(Boolean);
}

function isNumeric(value) {
  if (!String(value || "").trim()) return false;
  return Number.isFinite(Number(cleanToken(value)));
}

function isAmountToken(token) {
  const text = String(token || "");
  const cleaned = cleanToken(text);
  if (!cleaned) return false;
  if (!Number.isFinite(Number(cleaned))) return false;
  return text.includes("£") || cleaned.includes(".");
}

function isDateToken(token) {
  const parts = String(token || "").split("/");
  if (parts.length !== 3) return false;
  return parts.every((part) => part.length > 0 && Number.isFinite(Number(part)));
}

function looksLikeFlatToken(token) {
  const cleaned = String(token || "").replaceAll("&", ",").trim();
  if (!cleaned) return false;
  return cleaned.split("").every((char) => "0123456789,-".includes(char));
}

function expandFlatToken(token) {
  const cleaned = String(token || "").trim();
  if (!cleaned) return [];

  if (cleaned.includes("-")) {
    const parts = cleaned.split("-");
    const start = Number(parts[0]);
    const end = Number(parts[1]);
    if (Number.isFinite(start) && Number.isFinite(end) && end >= start) {
      return Array.from({ length: end - start + 1 }, (_, index) => String(start + index));
    }
  }

  return Number.isFinite(Number(cleaned)) ? [cleaned] : [];
}

function extractFlatsFromBlock(block) {
  const words = splitMany(block, [" "]);
  const tail = [];

  for (let index = words.length - 1; index >= 0; index -= 1) {
    const word = words[index].replaceAll("&", ",");
    if (looksLikeFlatToken(word)) tail.unshift(word);
    else break;
  }

  const expression = tail.join("").replaceAll("&", ",");
  const flats = splitMany(expression, [","]).flatMap(expandFlatToken);
  return [...new Set(flats)];
}

function extractBlockName(block) {
  const words = splitMany(block, [" "]);
  while (words.length && looksLikeFlatToken(words[words.length - 1])) words.pop();
  return words.join(" ") || block;
}

function hasPropertyWord(line) {
  const lower = String(line || "").toLowerCase();
  const words = ["court", "block", "flat", "house", "apartments", "estate", "building", "park", "tower", "lodge", "mansions"];
  return words.some((word) => lower.includes(word));
}

function isHeaderLine(line) {
  const lower = String(line || "").toLowerCase();
  const hits = ["date", "block", "amount", "work", "order", "description", "property"].filter((word) => lower.includes(word)).length;
  return hits >= 2;
}

function isStopLine(line) {
  const lower = String(line || "").toLowerCase();
  return lower.includes("total") || lower.includes("subtotal") || lower.includes("amount due") || lower.includes("balance due");
}

function scoreLineForTable(line) {
  const tokens = splitMany(line, [" ", tab]);
  let score = 0;

  if (isHeaderLine(line)) score += 3;
  if (hasPropertyWord(line)) score += 3;
  if (tokens.some(isAmountToken)) score += 2;
  if (tokens.some(isDateToken)) score += 1;
  if (tokens.some((token) => isNumeric(token) && cleanToken(token).length >= 4 && !isDateToken(token))) score += 1;
  if (extractFlatsFromBlock(line).length > 0) score += 1;
  if (isStopLine(line)) score -= 4;

  const lower = String(line || "").toLowerCase();
  if (lower.includes("invoice number") || lower.includes("tel") || lower.includes("email")) score -= 3;

  return score;
}

function detectCandidateTables(text) {
  const lines = String(text || "").replaceAll(String.fromCharCode(13), nl).split(nl).map((line) => line.trim()).filter(Boolean);
  const candidates = [];
  let current = null;
  let gapCount = 0;

  lines.forEach((line, index) => {
    const score = scoreLineForTable(line);
    const tableLike = score >= 3;
    const harmlessGap = line.includes("page break") || line === "-" || line === "---";

    if (tableLike) {
      if (!current) current = { id: uid(), start: index, end: index, lines: [], score: 0 };
      current.lines.push(line);
      current.end = index;
      current.score += score;
      gapCount = 0;
      return;
    }

    if (current && (harmlessGap || gapCount < 2) && !isStopLine(line)) {
      gapCount += 1;
      return;
    }

    if (current) {
      if (current.lines.length >= 2) candidates.push(current);
      current = null;
      gapCount = 0;
    }
  });

  if (current && current.lines.length >= 2) candidates.push(current);

  return candidates
    .map((candidate) => {
      const parsed = parseRowsFromLines(candidate.lines);
      const structureBonus = parsed.rows.length * 4;
      const propertyBonus = parsed.rows.filter((row) => hasPropertyWord(row.block)).length * 2;
      const penalty = parsed.rows.filter((row) => row.flats.length === 0).length;
      return { ...candidate, parsed, finalScore: candidate.score + structureBonus + propertyBonus - penalty };
    })
    .filter((candidate) => candidate.parsed.rows.length > 0)
    .sort((a, b) => b.finalScore - a.finalScore);
}

function parseRowsFromLines(lines) {
  const rows = [];
  const warnings = [];

  lines.forEach((line) => {
    if (isHeaderLine(line) || isStopLine(line)) return;

    const tokens = splitMany(line, [" ", tab]);
    if (tokens.length < 3) return;

    const dateIndex = tokens.findIndex(isDateToken);
    const amountIndex = tokens.findIndex(isAmountToken);

    if (amountIndex < 0) {
      warnings.push("No amount found: " + line);
      return;
    }

    const date = dateIndex >= 0 ? tokens[dateIndex] : "";
    const afterDateStart = dateIndex >= 0 ? dateIndex + 1 : 0;
    const workOrderCandidate = tokens.slice(amountIndex + 1).find((token) => isNumeric(token) && cleanToken(token).length >= 4) || "";
    const blockTokens = tokens.slice(afterDateStart, amountIndex);
    const block = blockTokens.join(" ").trim();

    if (!block || !hasPropertyWord(block)) {
      warnings.push("Rejected non-table or summary line: " + line);
      return;
    }

    rows.push({
      id: uid(),
      date,
      block,
      blockName: extractBlockName(block),
      flats: extractFlatsFromBlock(block),
      amount: toNumber(tokens[amountIndex]),
      workOrder: workOrderCandidate,
      originalLine: line
    });
  });

  return { rows, warnings };
}

function analyseDocument(text) {
  const candidates = detectCandidateTables(text);
  const best = candidates[0];
  return {
    candidates,
    selectedId: best ? best.id : "",
    parsed: best ? best.parsed : { rows: [], warnings: ["No suitable table found. Try a clearer PDF export, or paste the table text manually."] }
  };
}

function downloadCsv(filename, rows) {
  const quote = String.fromCharCode(34);
  const csv = rows.map((row) => row.map((cell) => quote + String(cell || "").replaceAll(quote, quote + quote) + quote).join(",")).join(nl);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function runTests() {
  const failures = [];
  const assert = (check, message) => { if (!check) failures.push(message); };

  assert(extractFlatsFromBlock("Janeford Court 4,7-10").join(",") === "4,7,8,9,10", "Expands flat ranges");
  assert(extractFlatsFromBlock("Dartford Court 6-7,16-18").join(",") === "6,7,16,17,18", "Expands multiple ranges");
  assert(extractBlockName("Janeford Court 4,7-10") === "Janeford Court", "Extracts block name");

  const analysed = analyseDocument(sampleText);
  assert(analysed.parsed.rows.length === 23, "Detects the main table and ignores invoice summary figures");
  assert(analysed.parsed.rows.every((row) => row.block.toLowerCase().includes("court")), "Only keeps property table rows");

  return failures;
}

export default function InvoiceSplitterApp() {
  const initialAnalysis = analyseDocument(sampleText);
  const [fileName, setFileName] = useState("");
  const [rawText, setRawText] = useState(sampleText);
  const [candidates, setCandidates] = useState(initialAnalysis.candidates);
  const [selectedId, setSelectedId] = useState(initialAnalysis.selectedId);
  const [parsed, setParsed] = useState(initialAnalysis.parsed);
  const [status, setStatus] = useState("Upload a PDF, TXT or CSV. The app will extract text, detect the most likely cost table, and create a block summary.");
  const [isUploading, setIsUploading] = useState(false);
  const [testFailures] = useState(runTests);

  const tableRows = parsed.rows;

  const splitRows = useMemo(() => {
    const rows = [];
    tableRows.forEach((row) => {
      const flats = row.flats.length ? row.flats : ["Unassigned"];
      const share = row.amount / flats.length;
      flats.forEach((flat) => rows.push({ ...row, flat, share }));
    });
    return rows;
  }, [tableRows]);

  const totalAmount = useMemo(() => tableRows.reduce((sum, row) => sum + row.amount, 0), [tableRows]);

  const totalsByBlock = useMemo(() => {
    const totals = {};
    tableRows.forEach((row) => {
      const key = row.blockName || extractBlockName(row.block);
      if (!totals[key]) totals[key] = { amount: 0, rowCount: 0, workOrders: new Set(), flats: new Set() };
      totals[key].amount += row.amount;
      totals[key].rowCount += 1;
      if (row.workOrder) totals[key].workOrders.add(row.workOrder);
      row.flats.forEach((flat) => totals[key].flats.add(flat));
    });

    return Object.entries(totals)
      .map(([block, info]) => ({
        block,
        amount: info.amount,
        rowCount: info.rowCount,
        workOrders: Array.from(info.workOrders).join(", "),
        flatCount: info.flats.size,
        flats: Array.from(info.flats).sort((a, b) => Number(a) - Number(b)).join(", ")
      }))
      .sort((a, b) => a.block.localeCompare(b.block));
  }, [tableRows]);

  const totalsByFlat = useMemo(() => {
    const totals = {};
    splitRows.forEach((row) => {
      const key = row.blockName + " - Flat " + row.flat;
      totals[key] = (totals[key] || 0) + row.share;
    });
    return Object.entries(totals).sort((a, b) => a[0].localeCompare(b[0]));
  }, [splitRows]);

  function applyAnalysis(text) {
    const result = analyseDocument(text);
    setCandidates(result.candidates);
    setSelectedId(result.selectedId);
    setParsed(result.parsed);
    setStatus(result.parsed.rows.length ? "Detected a likely table. Review the rows and export the block summary." : "No suitable table found.");
  }

  async function handleDocumentUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsUploading(true);
    setStatus("Uploading and extracting document text...");

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/extract", {
        method: "POST",
        body: formData,
      });

      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Upload failed.");

      setRawText(payload.text);
      applyAnalysis(payload.text);
    } catch (error) {
      setStatus(error.message || "Could not read that document.");
    } finally {
      setIsUploading(false);
    }
  }

  function analyseText() {
    applyAnalysis(rawText);
  }

  function selectCandidate(id) {
    const candidate = candidates.find((item) => item.id === id);
    if (!candidate) return;
    setSelectedId(id);
    setParsed(candidate.parsed);
    setStatus("Selected candidate table " + (candidates.indexOf(candidate) + 1) + ". Review the rows before exporting.");
  }

  function updateRow(id, field, value) {
    setParsed((current) => ({
      ...current,
      rows: current.rows.map((row) => {
        if (row.id !== id) return row;
        const updated = { ...row, [field]: value };
        if (field === "block") {
          updated.blockName = extractBlockName(value);
          updated.flats = extractFlatsFromBlock(value);
        }
        if (field === "amount") updated.amount = toNumber(value);
        return updated;
      })
    }));
  }

  function removeRow(id) {
    setParsed((current) => ({ ...current, rows: current.rows.filter((row) => row.id !== id) }));
  }

  function exportBlockSummary() {
    downloadCsv("invoice-block-summary.csv", [
      ["Block", "Number of charge rows", "Flat count", "Flats", "Work orders", "Total block cost"],
      ...totalsByBlock.map((row) => [row.block, row.rowCount, row.flatCount, row.flats, row.workOrders, row.amount.toFixed(3)])
    ]);
  }

  function exportFullSplit() {
    downloadCsv("invoice-full-split.csv", [
      ["Block summary"],
      ["Block", "Number of charge rows", "Flat count", "Flats", "Work orders", "Total block cost"],
      ...totalsByBlock.map((row) => [row.block, row.rowCount, row.flatCount, row.flats, row.workOrders, row.amount.toFixed(3)]),
      [],
      ["Flat-level split"],
      ["Date", "Block", "Block detail", "Flat", "Work order", "Original row amount", "Flat share"],
      ...splitRows.map((row) => [row.date, row.blockName, row.block, row.flat, row.workOrder, row.amount.toFixed(3), row.share.toFixed(3)]),
      [],
      ["Block and flat", "Total"],
      ...totalsByFlat.map(([name, total]) => [name, total.toFixed(3)])
    ]);
  }

  return (
    <div className="page">
      <main className="container">
        <section className="hero">
          <div>
            <p className="eyebrow">Property management tool</p>
            <h1>Invoice Block Summary</h1>
            <p className="intro">Upload a PDF, TXT or CSV. The app extracts the document text, detects the most likely cost table, ignores invoice-summary figures, and groups rows by block name.</p>
          </div>
          <label className="upload">
            {isUploading ? "Reading..." : "Upload document"}
            <input type="file" accept="application/pdf,text/plain,.txt,.csv" onChange={handleDocumentUpload} />
          </label>
        </section>

        {testFailures.length > 0 && (
          <section className="alert danger">
            <strong>Self-tests failed:</strong> {testFailures.join("; ")}
          </section>
        )}

        <section className="card">
          <div className="row between">
            <div>
              <p className="strong">{fileName || "No uploaded document yet"}</p>
              <p className="muted">{status}</p>
            </div>
            <div className="actions">
              <button className="secondary" onClick={() => setRawText(sampleText)}>Load example</button>
              <button onClick={analyseText}>Detect tables</button>
            </div>
          </div>
          <textarea value={rawText} onChange={(event) => setRawText(event.target.value)} placeholder="Extracted document text appears here..." />
        </section>

        <section className="metrics">
          <div><p>Candidate tables</p><strong>{candidates.length}</strong></div>
          <div><p>Selected rows</p><strong>{tableRows.length}</strong></div>
          <div><p>Original total</p><strong>{money(totalAmount)}</strong></div>
          <div><p>Split rows</p><strong>{splitRows.length}</strong></div>
        </section>

        <section className="card">
          <h2>Detected table candidates</h2>
          <p className="muted">The highest scoring table is selected automatically, but you can switch if needed.</p>
          <div className="candidateGrid">
            {candidates.map((candidate, index) => (
              <button key={candidate.id} onClick={() => selectCandidate(candidate.id)} className={candidate.id === selectedId ? "candidate selected" : "candidate"}>
                <span>Candidate {index + 1}</span>
                <small>Score {candidate.finalScore} · {candidate.parsed.rows.length} rows</small>
                <em>{candidate.lines.slice(0, 3).join(" | ")}</em>
              </button>
            ))}
            {candidates.length === 0 && <p className="muted">No candidate tables detected yet.</p>}
          </div>
        </section>

        <section className="card">
          <h2>Review selected rows</h2>
          <p className="muted">Only property/table rows should appear here. Edit or remove anything incorrect before exporting.</p>
          <div className="tableWrap">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Block text</th>
                  <th>Detected flats</th>
                  <th>Amount</th>
                  <th>Work order</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {tableRows.map((row) => (
                  <tr key={row.id}>
                    <td><input value={row.date} onChange={(event) => updateRow(row.id, "date", event.target.value)} /></td>
                    <td><input value={row.block} onChange={(event) => updateRow(row.id, "block", event.target.value)} /></td>
                    <td><span className="pill">{row.flats.length ? row.flats.join(", ") : "No flats found"}</span></td>
                    <td><input type="number" step="0.001" value={row.amount} onChange={(event) => updateRow(row.id, "amount", event.target.value)} /></td>
                    <td><input value={row.workOrder} onChange={(event) => updateRow(row.id, "workOrder", event.target.value)} /></td>
                    <td><button className="secondary" onClick={() => removeRow(row.id)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {parsed.warnings.length > 0 && (
            <div className="alert warning">
              {parsed.warnings.slice(0, 6).map((warning, index) => <p key={index}>Warning: {warning}</p>)}
            </div>
          )}
        </section>

        <section className="card">
          <div className="row between">
            <div>
              <h2>Block summary</h2>
              <p className="muted">Similar block names are grouped together, so all Janeford Court rows are added into one Janeford Court total.</p>
            </div>
            <div className="actions">
              <button onClick={exportBlockSummary}>Export block summary CSV</button>
              <button className="secondary" onClick={exportFullSplit}>Export full split CSV</button>
            </div>
          </div>
          <div className="tableWrap">
            <table>
              <thead>
                <tr>
                  <th>Block</th>
                  <th>Rows</th>
                  <th>Flats found</th>
                  <th>Work orders</th>
                  <th>Total block cost</th>
                </tr>
              </thead>
              <tbody>
                {totalsByBlock.map((row) => (
                  <tr key={row.block}>
                    <td><strong>{row.block}</strong></td>
                    <td>{row.rowCount}</td>
                    <td>{row.flats || "No flats listed"}</td>
                    <td>{row.workOrders}</td>
                    <td><strong>{money(row.amount)}</strong></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
